package com.bsuir.spring.main;
import com.bsuir.spring.service.GeneratorService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import java.util.List;
import java.util.Scanner;

public class Main {
    private static final String CONFIGURATION_PATH = "string.xml";
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext(CONFIGURATION_PATH);
        GeneratorService service = (GeneratorService) context.getBean("generatorService");
        String a;
        System.out.print("see language - 2, change string - 1 : ");
        Scanner in = new Scanner(System.in);
        int t=Integer.parseInt(in.next());

            List<String> generated1 = service.generateStrings(t);
            for (String s : generated1) { System.out.println(s);}}

    }

