package com.bsuir.spring.generator;

public interface StringGenerator {
    String EMPTY_STRING = "";
    String generate();
}
