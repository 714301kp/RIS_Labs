package com.bsuir.spring.generator;

import java.util.Scanner;

public class language implements StringGenerator {

    private String source1;
    public language(String source1) {
        this.source1 = source1; }
    @Override
        public String generate() {
            if (source1 == null || source1.isEmpty()) {
                return EMPTY_STRING;
            }

            System.out.print("Input 2 symbols: ");
            Scanner in = new Scanner(System.in);

            String resp = "";
            int c = 0;
            char[] arr = (in.next()).toCharArray();
          //  in.close();
            for (int i = 0; i < 2; i++) {
                if (((arr[i] >= 'a') && (arr[i] <= 'z')) || ((arr[i] >= 'A') && (arr[i] <= 'Z'))) {
                    c++;
                }
                if (c == 2)
                    resp = "English";
                else {
                    if (c == 1) {
                        resp = "Incorrect input!";
                    } else resp = "Russian";
                }
            }

                return resp;
               }}
