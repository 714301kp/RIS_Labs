package com.bsuir.spring.service;

import com.bsuir.spring.generator.StringGenerator;

import java.util.ArrayList;
import java.util.List;

public class GeneratorService {
    private StringGenerator stringGenerator1;
    private StringGenerator stringGenerator2;

    public GeneratorService() { }
    public GeneratorService(
            StringGenerator stringGenerator1,StringGenerator stringGenerator2) {

        this.stringGenerator1 = stringGenerator1;
        this.stringGenerator2=stringGenerator2;
    }

    public List<String> generateStrings(int t) {
        List<String> strings = new ArrayList<>();
        switch (t) {
            case 1: {
                strings.add(stringGenerator1.generate());
                return strings;
            }
            case 2: {
                strings.add(stringGenerator2.generate());
                return strings;
            }
            default:
                return strings;
        }
   }



    public StringGenerator getStringGenerator1() {
        return stringGenerator1;
    }
    public StringGenerator getStringGenerator2() {
        return stringGenerator2;
    }

    public void setStringGenerator1(StringGenerator stringGenerator1) {
        this.stringGenerator1 = stringGenerator1;
    }
    public void setStringGenerator2(StringGenerator stringGenerator2) {
        this.stringGenerator2 = stringGenerator2;
    }
}
