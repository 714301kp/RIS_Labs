package com.bsuir.spring.generator;

import java.util.Scanner;

public class Strings implements StringGenerator {

    private static  String[] english = {"f",",","d","u","l","t","`",";","p","b","q","r","k","v","y","j","g","h",
            "c","n","e","a","[","w","x","i","o","]","s","m","'",".","z",
                                        "F",",","D","U","L","T","`",";","P","B","Q","R","K","V","Y","J","G","H",
            "C","N","E","A","[","W","X","I","O","]","S","M","'",".","Z"};

    private static String [] russian = {"а","б","в","г","д","е","ё","ж","з","и","й","к","л","м","н","о","п","р",
            "с","т","у","ф","х","ц","ч","ш","щ","ъ","ы","ь","э","ю","я",
                                        "А","Б","В","Г","Д","Е","Ё","Ж","З","И","Й","К","Л","М","Н","О","П","Р",
            "С","Т","У","Ф","Х","Ц","Ч","Ш","Щ","Ъ","Ы","Ь","Э","Ю","Я"};

    static String word;
        private String source;
        public Strings(String source) {
            this.source = source; }
        @Override
        public String generate() {
            if (source == null || source.isEmpty())
            {
                return EMPTY_STRING;
            }

            System.out.print("Input: ");
            Scanner in = new Scanner(System.in);
            word=in.next();
            StringBuilder newWord = new StringBuilder("");

            for(int i=0;i<word.length();i++) {
                for(int j=0; j<english.length;j++) {
                    if(Character.toString(word.charAt(i)).equals(english[j])) {
                        newWord=newWord.append(russian[j]);
                    }
                }

            }
            if(source.contains(word))
                return newWord.toString();
            else {
                String falsetarget="Not found";
                return falsetarget;
            }
        }
    }
