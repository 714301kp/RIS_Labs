package com.kastsiukevich.lab8.dao;

import com.kastsiukevich.lab8.entity.Person;
import com.kastsiukevich.lab8.entity.PersonResponse;

public interface PersonDAO {

    int persistPerson(Person person);

    PersonResponse getPersonById(int id);

}
