package com.kastsiukevich.lab8.service;

import com.kastsiukevich.lab8.entity.Person;
import com.kastsiukevich.lab8.entity.PersonResponse;

public interface PersonService {

    int persistPerson(Person person);

    PersonResponse getPersonById(int id);
}