/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mdb;

import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.ejb.MessageDrivenContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import java.util.*;
import java.io.*;
import java.nio.charset.Charset;
import java.util.logging.Level;
import javax.annotation.PreDestroy;

/**
 *
 * @author tatia
 */
@MessageDriven(activationConfig = {
    @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "jms/Queue"),
    @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue")
})// указываем очередь, для прослушивания сообщений
public class SimpleMessageBean implements MessageListener {
    
   @Resource
   private MessageDrivenContext mdc;// создаем экземпляр интерфейса MessageDrivenContext
   
   private List<String> list= new ArrayList();//создаем список строк
   
   static final Logger logger = Logger.getLogger("SimpleMessageBean"); 
   
 
   
   
   
    public SimpleMessageBean() {
    }
    
    @Override
    public void onMessage(Message inMessage) {
        TextMessage msg = null; // объект текстового сообщения, т.к сообщения содержат строки
 try {
       if (inMessage instanceof TextMessage) {// проверяем, текстовое ли сообщение пришло
         msg = (TextMessage) inMessage;// присваиваем текст сообщения переменной
          logger.info("MESSAGE BEAN: Message received: "
             + msg.getText());//выводим информацию о пришедшем сообщении
              
               writeToTextFile(msg.getText());//вызываем метод, который записывает принятое сообщение в файл 
            } else {
            logger.warning("Message of wrong type: "
               + inMessage.getClass().getName()); // если сообщение не текстовое
            }
         } catch (JMSException e) {
              e.printStackTrace();
              mdc.setRollbackOnly();//отмечаем текущую транзакцию для отката
           } catch (Throwable te) {
 te.printStackTrace();
 }
       
 }
   
    
    public void sortList(){// метод сортировки строк по длине и перезаписи отсортированного списка строк в файл
           try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\tatia\\OneDrive\\Документы\\NetBeansProjects\\ot.txt")))//открываем файл для чтения
                  {
                    //чтение построчно
                   String s;
                    while((s=br.readLine())!=null){
                        list.add(s);// добавляем строки из файла в список
                      }
                   }catch(IOException ex){       
                     System.out.println(ex.getMessage());
                     } 
         Collections.sort(list, new Comparator<String>() { 
            @Override
            public int compare(String o1, String o2) {
                return o1.length() - o2.length();
            }// сравниваем строки из списка по длине
        });
         try(FileWriter writer = new FileWriter("C:\\Users\\tatia\\OneDrive\\Документы\\NetBeansProjects\\ot.txt",false))//запись списка в файл, с удалением прежнего содержимого
        {
           for(String s:list){ 
            writer.write(s);
            writer.write('\n');
        }
             writer.flush();
           
        }
        catch(IOException ex){
             
            System.out.println(ex.getMessage());
        } 
         
         
    }
    public void writeToTextFile(String s) throws JMSException, FileNotFoundException, IOException{
       
        try(FileWriter writer = new FileWriter("C:\\Users\\tatia\\OneDrive\\Документы\\NetBeansProjects\\ot.txt", true))// создаем объект writer, чтобы записать строку в существующий файл, не уничтожая имеющегося в нем содержимого
        {
          
             
            writer.write(s);//
            writer.write('\n');
            writer.flush();//освобождаем writer
        }
        catch(IOException ex){
             
            System.out.println(ex.getMessage());
        } 
        sortList();// вызываем метод сортировки сообщений
        }
    
    
    }
    
