/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simplemessageclient;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.*;
import javax.annotation.Resource;

/**
 *
 * @author tatia
 */
public class SimpleMessageClient {

    @Resource(mappedName="jms/ConnectionFactory") // добавляем ресурс фабрики соединений
    private static ConnectionFactory connectionFactory;
    
    @Resource(mappedName="jms/Queue")//добавляем ресурс путнка назначения
    private static Queue queue;
    
  


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String mes = "This is message ";// строка сообщения
        try{
    Connection connection = connectionFactory.createConnection();//создаем соединение
            Session session = connection.createSession(false,
               Session.AUTO_ACKNOWLEDGE); // создаем сессию
                        MessageProducer messageProducer =
                           session.createProducer(queue);// создаем производителя сообщений
                        TextMessage message = session.createTextMessage();// создаем текстовое сообщ
                          for (int i = 0; i < 10; i++) {
                              
                                  for(int k=i; k>=0; k--){
                                      mes+=k;
                                  } // создаем текст сообщение таким образом, чтобы длина была различная
                                   message.setText(mes);//задаем текст сообщения
                                   System.out.println("Sending message: " +
                                    message.getText());// выводим сведения об отправке на консоль
                                   messageProducer.send(message); } // отправляем
        }catch (JMSException e) {
             System.err.println("Exception occurred: " + e.toString());
         }
        
        
        
    }
    
}
