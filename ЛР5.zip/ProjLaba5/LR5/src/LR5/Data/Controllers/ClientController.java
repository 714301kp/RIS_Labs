﻿import javax.ejb.EJB;

import javax.faces.bean.ManagedBean;

import javax.faces.bean.SessionScoped;

import java.io.Serializable;

import java.util.List;


    public class ClientController : Controller
    {
        private readonly IClients _allClients;
        private readonly AppDBContent appDBContent;
        public ClientController(IClients iclients, AppDBContent apd)
        {
            _allClients = iclients;
            this.appDBContent = apd;
        }

        public ActionResult Index()
        {
            if (HttpContext.Session.GetString("actions") == "admin")
            {
                using (appDBContent)
                {
                    return View(appDBContent.Client.ToList());
                }
            }
            else
            {
                //return RedirectToAction("Employee/Login");
                return RedirectToRoute(new { controller = "Employee", action = "Login" });
            }
        }

        public ActionResult Details(int id)
        {
            if (HttpContext.Session.GetString("actions") == "admin")
            {
                using (appDBContent)
                {
                    return View(appDBContent.Client.Where(x => x.id == id).FirstOrDefault());
                }
            }
            else return RedirectToRoute(new { controller = "Employee", action = "Login" });
        }

        [HttpGet]
        public ActionResult Create()
        {
            if (HttpContext.Session.GetString("actions") == "admin")
            {
                return View();
            }
            else return RedirectToRoute(new { controller = "Employee", action = "Login" });
        }
        [HttpPost]
        public ActionResult Create(Client client)
        {
            if (HttpContext.Session.GetString("actions") == "admin")
            {
                try
                {
                    using (appDBContent)
                    {
                        appDBContent.Client.Add(client);
                        appDBContent.SaveChanges();
                    }
                    return RedirectToAction("Index");
                }
                catch
                {
                    return View();
                    //return RedirectToAction("Index");
                }
            }
            else return RedirectToRoute(new { controller = "Employee", action = "Login" });
        }


        [HttpGet]
        public ActionResult Edit(int id)
        {
            if (HttpContext.Session.GetString("actions") == "admin")
            {
                using (appDBContent)
                {
                    return View(appDBContent.Client.Where(x => x.id == id).FirstOrDefault());
                }
            }
            else return RedirectToRoute(new { controller = "Employee", action = "Login" });
        }
        [HttpPost]
        public ActionResult Edit(int id, Client client)
        {
            if (HttpContext.Session.GetString("actions") == "admin")
            {
                try
                {
                    using (appDBContent)
                    {
                        client.id = id;
                        appDBContent.Entry(client).State = EntityState.Modified;
                        appDBContent.SaveChanges();
                    }
                    return RedirectToAction("Index");
                }
                catch
                {
                    return View();
                }
            }
            else return RedirectToRoute(new { controller = "Employee", action = "Login" });
        }


        [HttpGet]
        public ActionResult Delete(int id)
        {
            if (HttpContext.Session.GetString("actions") == "admin")
            {
                using (appDBContent)
                {
                    return View(appDBContent.Client.Where(x => x.id == id).FirstOrDefault());
                }
            }
            else return RedirectToRoute(new { controller = "Employee", action = "Login" });
        }
        [HttpPost]
        public ActionResult Delete(int id, Client cl)
        {
            if (HttpContext.Session.GetString("actions") == "admin")
            {
                try
                {
                    using (appDBContent)
                    {
                        Client client = appDBContent.Client.Where(x => x.id == id).FirstOrDefault();
                        
                            appDBContent.Client.Remove(client);
                            appDBContent.SaveChanges();
                        
                    }
                    return RedirectToAction("Index");
                }
                catch
                {
                    return View("Delete");
                }
            }
            else return RedirectToRoute(new { controller = "Employee", action = "Login" });
        }


        public ActionResult EmployeeViewClients()
        {
            if (!(HttpContext.Session.GetString("actions") == "admin" || HttpContext.Session.GetString("actions") == "guest"))
            {
                int EmployeeID = int.Parse(HttpContext.Session.GetString("actions"));
                using (appDBContent)
                {
                    return View(appDBContent.Client.ToList());
                }
            }
            else
            {
                //return RedirectToAction("Employee/Login");
                return RedirectToRoute(new { controller = "Employee", action = "Login" });
            }
        }

        [HttpGet]
        public ActionResult CreateClientByEmployee()
        {
            if (!(HttpContext.Session.GetString("actions") == "admin" || HttpContext.Session.GetString("actions") == "guest"))
            {
                return View();
            }
            else return RedirectToRoute(new { controller = "Employee", action = "Login" });
        }
        [HttpPost]
        public ActionResult CreateClientByEmployee(Client client)
        {
            if (!(HttpContext.Session.GetString("actions") == "admin" || HttpContext.Session.GetString("actions") == "guest"))
            {
                try
                {
                    using (appDBContent)
                    {
                        appDBContent.Client.Add(client);
                        appDBContent.SaveChanges();
                    }
                    return RedirectToAction("EmployeeViewClients");
                }
                catch
                {
                    return View();
                    //return RedirectToAction("Index");
                }
            }
            else return RedirectToRoute(new { controller = "Employee", action = "Login" });
        }

