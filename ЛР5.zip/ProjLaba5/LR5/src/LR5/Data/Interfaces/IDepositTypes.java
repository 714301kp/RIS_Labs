﻿import javax.ejb.EJB;

import javax.faces.bean.ManagedBean;

import javax.faces.bean.SessionScoped;

import java.io.Serializable;

import java.util.List;

    public interface IDepositTypes
    {
        IEnumerable<DepositType> AllDepositTypes { get; }
    }
