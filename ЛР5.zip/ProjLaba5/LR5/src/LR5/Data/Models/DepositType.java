﻿import javax.ejb.EJB;

import javax.faces.bean.ManagedBean;

import javax.faces.bean.SessionScoped;

import java.io.Serializable;

import java.util.List;

    public class DepositType
    {
        public int id { get; set; }
        public string typeName { get; set; }
        public int minMoney { get; set; }
        public int maxMoney { get; set; }
        public int period { get; set; }
        public int capitalization { get; set; }
        public int percent { get; set; }
        public List<Deposit> deposits { set; get; }
    }

