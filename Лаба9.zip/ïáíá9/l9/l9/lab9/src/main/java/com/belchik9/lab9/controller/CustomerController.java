package com.belchik9.lab9.controller;

import com.belchik9.lab9.CustomerModelAssembler;
import com.belchik9.lab9.exception.CustomerNotFoundException;
import com.belchik9.lab9.model.Customer;
import com.belchik9.lab9.model.CustomerResponse;
import com.belchik9.lab9.repository.CitizenshipRepository;
import com.belchik9.lab9.repository.CityRepository;
import com.belchik9.lab9.repository.CustomerRepository;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
public class CustomerController {

    private final CustomerRepository customerRepository;
    private final CitizenshipRepository citizenshipRepository;
    private final CityRepository cityRepository;
    private final CustomerModelAssembler assembler;

    public CustomerController(CustomerRepository repository, CitizenshipRepository citizenshipRepository, CityRepository cityRepository, CustomerModelAssembler assembler) {
        this.customerRepository = repository;
        this.citizenshipRepository = citizenshipRepository;
        this.cityRepository = cityRepository;
        this.assembler = assembler;
    }

    @GetMapping("/customers/read")
    public CollectionModel getAll() {
        List<Customer> customers = customerRepository.findAll();
        List<CustomerResponse> responses = new ArrayList<>();

        for (Customer customer : customers) {
            CustomerResponse response = new CustomerResponse(customer);
            response.setCity(cityRepository.findById(customer.getCity()).orElseThrow(null));
            response.setCitizenship(citizenshipRepository.findById(customer.getCitizenship()).orElseThrow(null));
            responses.add(response);
        }

        List<EntityModel<CustomerResponse>> customerResponses = responses.stream().map(assembler::toModel).collect(Collectors.toList());

        return new CollectionModel<>(customerResponses, linkTo(methodOn(CustomerController.class).getAll()).withSelfRel());
    }

    @PostMapping("/customers/add")
    ResponseEntity<Customer> newCustomer(@RequestBody Customer newCustomer) {
        if (newCustomer.areFieldsValid()) {
            return new ResponseEntity<>(customerRepository.save(newCustomer), HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/customers/read/{idCustomer}")
    public EntityModel<CustomerResponse> getCustomer(@PathVariable int idCustomer) {
        Customer customer = customerRepository.findById(idCustomer).orElseThrow(() -> new CustomerNotFoundException(idCustomer));
        CustomerResponse response = new CustomerResponse(customer);
        System.out.println(customer.getCity() + " City id");
        response.setCity(cityRepository.findById(customer.getCity()).orElseThrow(null));
        response.setCitizenship(citizenshipRepository.findById(customer.getCitizenship()).orElseThrow(null));
        return assembler.toModel(response);
    }

    @PutMapping("/customers/update/{idCustomer}")
    ResponseEntity<Customer> replaceCustomer(@RequestBody Customer newCustomer, @PathVariable int idCustomer) {
        if (newCustomer.areFieldsValid()) {
            return new ResponseEntity<>(customerRepository.findById(idCustomer).map(customer -> {
                newCustomer.setIdCustomer(idCustomer);
                return customerRepository.save(newCustomer);
            }).orElseGet(() -> {
                newCustomer.setIdCustomer(idCustomer);
                return customerRepository.save(newCustomer);
            }), HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @DeleteMapping("/customers/delete/{idCustomer}")
    void deleteCustomer(@PathVariable int idCustomer) {
        customerRepository.deleteById(idCustomer);
    }

}
