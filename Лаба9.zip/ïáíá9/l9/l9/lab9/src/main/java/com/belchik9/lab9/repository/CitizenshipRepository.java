package com.belchik9.lab9.repository;

import com.belchik9.lab9.model.Citizenship;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CitizenshipRepository extends JpaRepository<Citizenship, Integer> {
}