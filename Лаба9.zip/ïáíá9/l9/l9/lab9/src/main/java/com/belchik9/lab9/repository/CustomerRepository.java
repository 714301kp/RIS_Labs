package com.belchik9.lab9.repository;


import com.belchik9.lab9.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
}
