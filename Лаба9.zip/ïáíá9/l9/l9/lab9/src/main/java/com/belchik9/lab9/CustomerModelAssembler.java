package com.belchik9.lab9;

import com.belchik9.lab9.controller.CustomerController;
import com.belchik9.lab9.model.CustomerResponse;
import org.springframework.stereotype.Component;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;


@Component
public class CustomerModelAssembler implements RepresentationModelAssembler<CustomerResponse, EntityModel<CustomerResponse>> {

    @Override
    public EntityModel<CustomerResponse> toModel(CustomerResponse customer) {
        return new EntityModel<>(customer,
                linkTo(methodOn(CustomerController.class).getCustomer(customer.getIdCustomer())).withSelfRel(),
                linkTo(methodOn(CustomerController.class).getAll()).withRel("customers"));
    }

}