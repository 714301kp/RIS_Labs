package com.belchik9.lab9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab9Application {
	public static void main(String[] args) {
		SpringApplication.run(Lab9Application.class, args);
	}
}
