package com.belchik9.lab9.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import java.io.Serializable;
import java.util.Date;
import java.util.Optional;

@XmlRootElement(name = "response")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlSeeAlso({Citizenship.class, City.class})
public class CustomerResponse implements Serializable {

    private int idCustomer;
    private String surname;
    private String name;
    private String midname;
    private Date dateOfBirth;
    private String passportSeries;
    private String passportNumber;
    private String addressFact;
    private Optional<String> phoneNumber;
    private Optional<String> phoneHome;
    private String addressRegistration;
    private City city;
    private Citizenship citizenship;

    public CustomerResponse(int idCustomer, String surname, String name, String midname, Date dateOfBirth, String passportSeries, String passportNumber, String addressFact, Optional<String> phoneNumber, Optional<String> phoneHome, String addressRegistration, City city, Citizenship citizenship) {
        this.idCustomer = idCustomer;
        this.surname = surname;
        this.name = name;
        this.midname = midname;
        this.dateOfBirth = dateOfBirth;
        this.passportSeries = passportSeries;
        this.passportNumber = passportNumber;
        this.addressFact = addressFact;
        this.phoneNumber = phoneNumber;
        this.phoneHome = phoneHome;
        this.addressRegistration = addressRegistration;
        this.city = city;
        this.citizenship = citizenship;
    }

    public CustomerResponse(Customer customer) {
        this.idCustomer = customer.getIdCustomer();
        this.surname = customer.getSurname();
        this.name = customer.getName();
        this.midname = customer.getMidname();
        this.dateOfBirth = customer.getDateOfBirth();
        this.passportSeries = customer.getPassportSeries();
        this.passportNumber = customer.getPassportNumber();
        this.addressFact = customer.getAddressFact();
        this.phoneNumber = customer.getPhoneNumber();
        this.phoneHome = customer.getPhoneHome();
        this.addressRegistration = customer.getAddressRegistration();
    }

    public CustomerResponse() {
    }

    public int getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(int idCustomer) {
        this.idCustomer = idCustomer;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMidname() {
        return midname;
    }

    public void setMidname(String midname) {
        this.midname = midname;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getPassportSeries() {
        return passportSeries;
    }

    public void setPassportSeries(String passportSeries) {
        this.passportSeries = passportSeries;
    }

    public String getPassportNumber() {
        return passportNumber;
    }

    public void setPassportNumber(String passportNumber) {
        this.passportNumber = passportNumber;
    }

    public String getAddressFact() {
        return addressFact;
    }

    public void setAddressFact(String addressFact) {
        this.addressFact = addressFact;
    }

    public Optional<String> getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(Optional<String> phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Optional<String> getPhoneHome() {
        return phoneHome;
    }

    public void setPhoneHome(Optional<String> phoneHome) {
        this.phoneHome = phoneHome;
    }

    public String getAddressRegistration() {
        return addressRegistration;
    }

    public void setAddressRegistration(String addressRegistration) {
        this.addressRegistration = addressRegistration;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public Citizenship getCitizenship() {
        return citizenship;
    }

    public void setCitizenship(Citizenship citizenship) {
        this.citizenship = citizenship;
    }
}