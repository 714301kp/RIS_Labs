package com.belchik9.lab9.exception;

public class CustomerNotFoundException extends RuntimeException {

    public CustomerNotFoundException(int idCustomer) {
        super("Couldn't find customer " + idCustomer);
    }

}
