package com.belchik9.lab9.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "citizenship")
public class Citizenship implements Serializable {

    @Id
    private int idCitizenship;
    private String nameCitizenship;

    public Citizenship(int idCitizenship, String nameCitizenship) {
        this.idCitizenship = idCitizenship;
        this.nameCitizenship = nameCitizenship;
    }

    public Citizenship() {
    }

    public int getIdCitizenship() {
        return idCitizenship;
    }

    public void setIdCitizenship(int idCitizenship) {
        this.idCitizenship = idCitizenship;
    }

    public String getNameCitizenship() {
        return nameCitizenship;
    }

    public void setNameCitizenship(String nameCitizenship) {
        this.nameCitizenship = nameCitizenship;
    }
}

