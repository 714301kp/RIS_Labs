package com.belchik9.lab9.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Optional;

@Entity
@Table(name = "customer")
public class Customer implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idCustomer;
    private String surname;
    private String name;
    private String midname;

    @JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    private Date dateOfBirth;

    private String passportSeries;
    private String passportNumber;

    @Column(name = "addressFact", nullable = false)
    private String addressFact;

    private String phoneNumber;
    private String phoneHome;
    private String addressRegistration;
    private int city;
    private int citizenship;

    public Customer(int idCustomer, String surname, String name, String midname, Date dateOfBirth, String passportSeries, String passportNumber, String addressFact, String phoneNumber, String phoneHome, String addressRegistration, int city, int citizenship) {
        this.idCustomer = idCustomer;
        this.surname = surname;
        this.name = name;
        this.midname = midname;
        this.dateOfBirth = dateOfBirth;
        this.passportSeries = passportSeries;
        this.passportNumber = passportNumber;
        this.addressFact = addressFact;
        this.phoneNumber = phoneNumber;
        this.phoneHome = phoneHome;
        this.addressRegistration = addressRegistration;
        this.city = city;
        this.citizenship = citizenship;
    }

    public Customer() {
    }

    public int getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(int idCustomer) {
        this.idCustomer = idCustomer;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMidname() {
        return midname;
    }

    public void setMidname(String midname) {
        this.midname = midname;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getPassportSeries() {
        return passportSeries;
    }

    public void setPassportSeries(String passportSeries) {
        this.passportSeries = passportSeries;
    }

    public String getPassportNumber() {
        return passportNumber;
    }

    public void setPassportNumber(String passportNumber) {
        this.passportNumber = passportNumber;
    }

    public String getAddressFact() {
        return addressFact;
    }

    public void setAddressFact(String addressFact) {
        this.addressFact = addressFact;
    }

    public Optional<String> getPhoneNumber() {
        return Optional.ofNullable(phoneNumber);
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Optional<String> getPhoneHome() {
        return Optional.ofNullable(phoneHome);
    }

    public void setPhoneHome(String phoneHome) {
        this.phoneHome = phoneHome;
    }

    public String getAddressRegistration() {
        return addressRegistration;
    }

    public void setAddressRegistration(String addressRegistration) {
        this.addressRegistration = addressRegistration;
    }

    public int getCity() {
        return city;
    }

    public void setCity(int city) {
        this.city = city;
    }

    public int getCitizenship() {
        return citizenship;
    }

    public void setCitizenship(int citizenship) {
        this.citizenship = citizenship;
    }

    public boolean areFieldsValid() {
        return this.surname != null
                && this.name != null
                && this.midname != null
                && this.dateOfBirth != null
                && this.addressFact != null
                && this.addressRegistration != null;
    }
}
