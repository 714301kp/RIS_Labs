package com.konopelkoyana.springintroduction;

import java.text.ParseException;
import java.util.List;

public class EquationService {
    private IEquationResolver<Number> equationResolver;

// в данной части кода мы видим что нашего Service усть зависимость IEquationResolver (от интерфейса)
    // и эта зависимость удовлетворена при помощи QuadraticEquationResolver
    public EquationService(IEquationResolver<Number> equationResolver) {
        this.equationResolver = equationResolver;
    }


    public List<Number> resolve(List<Number> param) throws Exception {
        return equationResolver.Resolve(param);
    }
}
