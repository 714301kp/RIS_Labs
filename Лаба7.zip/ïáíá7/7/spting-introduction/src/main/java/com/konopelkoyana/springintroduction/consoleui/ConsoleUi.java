package com.konopelkoyana.springintroduction.consoleui;

import com.konopelkoyana.springintroduction.EquationService;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ConsoleUi implements IConsoleUi {
    private final EquationService service;


    public ConsoleUi(EquationService service) {
        this.service = service;
    }


    @Override
    public int go() {
        Scanner scan = new Scanner(System.in);
        String input;

        while (true) {
            System.out.println("Введите параметры уравнения либо '/e' чтобы выйти.");
            List<Number> params = new ArrayList<>();

            System.out.print("Введите A: ");
            input = scan.nextLine();
            if (input.equals("/e")) return 0;
            params.add(Double.parseDouble(input));

            System.out.print("Введите B: ");
            input = scan.nextLine();
            if (input.equals("/e")) return 0;
            params.add(Double.parseDouble(input));

            System.out.print("Введите C: ");
            input = scan.nextLine();
            if (input.equals("/e")) return 0;
            params.add(Double.parseDouble(input));

            System.out.print("Введите D: ");
            input = scan.nextLine();
            if (input.equals("/e")) return 0;
            params.add(Double.parseDouble(input));
            System.out.println(String.format(
                    "Полученное уравнение: %fx^2 + %fx +%f = %f",
                    params.get(0), params.get(1), params.get(2), params.get(3)
            ));

            System.out.println(tryResolve(params));
        }
    }

    private String tryResolve(List<Number> params) {
        try {
            List<Number> result = service.resolve(params);
            return "Резльтат - X1: " + result.get(0) + " X2: " + result.get(1);
        } catch (Exception ex) {
            return ex.getMessage();
        }
    }
}
