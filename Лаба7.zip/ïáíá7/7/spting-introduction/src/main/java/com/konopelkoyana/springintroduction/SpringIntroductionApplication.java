package com.konopelkoyana.springintroduction;

import com.konopelkoyana.springintroduction.consoleui.ConsoleUi;
import com.konopelkoyana.springintroduction.consoleui.IConsoleUi;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Scanner;


public class SpringIntroductionApplication {

    private static final String CONFIGURATION_PATH = "equation.xml";

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext(CONFIGURATION_PATH);

        EquationService service = (EquationService) context.getBean("equationService");//получение Бина

        IConsoleUi ui = new ConsoleUi(service);
        ui.go();
    }
}
