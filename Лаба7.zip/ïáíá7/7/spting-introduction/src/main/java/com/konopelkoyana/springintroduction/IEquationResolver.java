package com.konopelkoyana.springintroduction;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public interface IEquationResolver<TNumber extends Number> {
    List<TNumber> Resolve(List<TNumber> params) throws Exception;
}
