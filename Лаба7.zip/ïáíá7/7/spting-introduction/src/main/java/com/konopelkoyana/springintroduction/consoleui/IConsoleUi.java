package com.konopelkoyana.springintroduction.consoleui;

public interface IConsoleUi {
    int go();
}
