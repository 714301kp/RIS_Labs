package com.konopelkoyana.springintroduction;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
// данный класс внедряется на место IEquationResolver
public class QuadraticEquationResolver implements IEquationResolver<Double>  {

    private Pattern quadraticEquationPattern
            = Pattern.compile("(-?\\d+)x\\^2 +([+-]\\d+)x +([+-]\\d+)\\s+= +\\d+", Pattern.CASE_INSENSITIVE);
    private Pattern findAPattern = Pattern.compile("-?\\d+(?=x\\^2)");
    private Pattern findBPattern = Pattern.compile("-?\\d+(?=x )");
    private Pattern findCPattern = Pattern.compile("\\d+(?= +=)");
    private Pattern findDPattern = Pattern.compile("");

    @Override
    public List<Double> Resolve(List<Double> params) throws Exception {
        if (params.size() != 4) {
            throw new Exception("Invalid number of params!");
        }

        // ax^2 + bx + c = d
        Double paramA = params.get(0);
        Double paramB = params.get(1);
        Double paramC = params.get(2);
        Double paramD = params.get(3);

        paramC -= paramD;

        double discriminant = Math.pow(paramB, 2) - 4 * paramA * paramC;

        Double x1 = (-1 * paramB + Math.pow(discriminant, 0.5)) / (paramA * 2);
        Double x2 = (-1 * paramB - Math.pow(discriminant, 0.5)) / (paramA * 2);

        List<Double> results = new ArrayList<>();
        results.add(x1);
        results.add(x2);

        return results;
    }
}
