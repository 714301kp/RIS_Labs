import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet(name = "TerminalServlet")
public class TerminalServlet extends HttpServlet {

    @EJB
    Terminal terminal;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String button = req.getParameter("button");
        if (button.equals("add_btn")) {
            Ticket ticket = new Ticket();
            ticket.setCityDeparture(req.getParameter("cityDeparture"));
            ticket.setCityArrival(req.getParameter("cityArrival"));
            ticket.setPrice(Double.parseDouble(req.getParameter("price")));
            ticket.setView(req.getParameter("view"));
            terminal.addTicket(ticket);
        }
        ArrayList<Ticket> ticketArrayList = terminal.getTicketArrayList();
        if (button.equals("range_btn")) {
            ticketArrayList = terminal.getTicketsView(req.getParameter("enterClass"));
        }

        if (button.matches("del_btn(.*)")) {
            String buff[] = button.split("-");
            terminal.deleteTicket(Integer.parseInt(buff[1]));
        }
        printPage(resp, ticketArrayList);
    }

    private void printPage(HttpServletResponse resp, ArrayList<Ticket> ticketArrayList) throws IOException {
        PrintWriter printWriter = resp.getWriter();
        printWriter.println("<!DOCTYPE html>\n" +
                "<html lang=\"en\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <title>Railway station</title>\n" +
                "</head>\n" +
                "<body>\n" +
                "<form action=\"TerminalServlet\" method=\"POST\">\n" +
                "  <h1>Railway station</h1><br/>" +
                "    City of departure: <input name=\"cityDeparture\"/>\n" +
                "    City arrival: <input name=\"cityArrival\"/>\n" +
                "    Price: <input name=\"price\"/>\n" +
                "    View: <input name=\"view\"/>\n" +
                "    <button type=\"submit\" name=\"button\" value=\"add_btn\">Add</button>\n" +
                "    <br/>\n" +
                "        <br/>\n" +
                "\n" +
                "   <br/>\n" +
                "    Enter the class: <input name=\"enterClass\"/>" +
                "<button type=\"submit\" name=\"button\" value=\"range_btn\">find</button> <br />" +
                "      Ticket: <br> <div >");
        if (!ticketArrayList.isEmpty()) {
            for (int i = 0; i < ticketArrayList.size(); i++) {
                printWriter.println("<b>" + ticketArrayList.get(i).getCityDeparture() + "</b>  " + ticketArrayList.get(i).getCityArrival()
                        + ", " + ticketArrayList.get(i).getPrice() + "BYN " + ", " + ticketArrayList.get(i).getView()
                        + " <button type=\"submit\" name=\"button\" value=\"del_btn-" + i + "\">delete</button>" + "<br/>");
            }
        }
        printWriter.println("</div>\n" +
                "</form>\n" +
                "</body>\n" +
                "</html>");
    }
}
