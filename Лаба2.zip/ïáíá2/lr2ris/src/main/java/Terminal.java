import javax.ejb.Singleton;
import java.util.ArrayList;
import java.util.Iterator;

@Singleton
public class Terminal {
    ArrayList<Ticket> ticketArrayList = new ArrayList<>();

    public void addTicket(Ticket ticket) {
        ticketArrayList.add(ticket);
    }

    public void deleteTicket(int index) {
        ticketArrayList.remove(index);
    }

    public ArrayList<Ticket> getTicketsView(String viewSearch) {
        ArrayList<Ticket> result = new ArrayList<>();
        Iterator<Ticket> itr = ticketArrayList.iterator();

        while (itr.hasNext()) {
            Ticket ticketElement = itr.next();
            if (ticketElement.getView().equals(viewSearch) && ticketElement.getPrice() < 50.0) {
                result.add(ticketElement);
            }
        }
        return result;
    }

    public ArrayList<Ticket> getTicketArrayList() {
        return ticketArrayList;
    }

    public void setTicketArrayList(ArrayList<Ticket> ticketArrayList) {
        this.ticketArrayList = ticketArrayList;
    }
}
//аннотация ejb
//последовательность обработки