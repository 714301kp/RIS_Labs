package by.ris.lab89.controller;

import by.ris.lab89.entity.ClientEntity;
import by.ris.lab89.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
public class MainController {

    private final ClientService service;

    @Autowired
    public MainController(ClientService service) {
        this.service = service;
    }

    @GetMapping(value = "/xml", produces = MediaType.APPLICATION_XML_VALUE)
    public List<ClientEntity> getAllClients() {
        return service.getClients();
    }

    @GetMapping(value = "/json", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<ClientEntity> getAllClientsJson() {
        return service.getClients();
    }

    @PostMapping(value = "/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ClientEntity addClient(@RequestBody ClientEntity clientEntity)
    {
        service.addClient(clientEntity);
        return clientEntity;
    }

    @PostMapping(value = "/x", consumes = MediaType.APPLICATION_XML_VALUE, produces = MediaType.APPLICATION_XML_VALUE)
    public ClientEntity addClientt(@RequestBody ClientEntity clientEntity)
    {
        service.addClientt(clientEntity);
        return clientEntity;
    }

    @DeleteMapping(value = "/{id}")
    public void deleteClient(@PathVariable int id) {
        service.deleteClient(id);
    }

    @PutMapping(value = "/clients", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<ClientEntity> addClients(@RequestBody List<ClientEntity> clients) {
        return service.addClients(clients);
    }

    @DeleteMapping(value = "/clients", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> removeClients(@RequestBody List<ClientEntity> clientEntities) {
        service.deleteClients(clientEntities);
        List<Integer> list = clientEntities.stream().map(ClientEntity::getId).collect(Collectors.toList());
        return ResponseEntity.ok("Clients with ids: " + list + "successfully deleted");
    }
}
