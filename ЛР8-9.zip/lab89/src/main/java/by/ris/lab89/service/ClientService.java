package by.ris.lab89.service;

import by.ris.lab89.dao.ClientRepository;
import by.ris.lab89.entity.ClientEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClientService {

    private final ClientRepository repository;

    @Autowired
    public ClientService(ClientRepository repository) {
        this.repository = repository;
    }

    public List<ClientEntity> getClients() {
        return (List<ClientEntity>) repository.findAll();
    }

    public ClientEntity addClient(ClientEntity client) {
        return repository.save(client);
    }

    public List<ClientEntity> addClients(List<ClientEntity> entities) {
        return (List<ClientEntity>) repository.saveAll(entities);
    }

    public ClientEntity updateClient(ClientEntity clientEntity) {
        return repository.save(clientEntity);
    }

    public void deleteClient(Integer id) {
        repository.deleteById(id);
    }

    public void deleteClients(List<ClientEntity> ids) {
        repository.deleteAll(ids);
    }

    public ClientEntity addClientt(ClientEntity clientEntity) { return repository.save(clientEntity); }
}
