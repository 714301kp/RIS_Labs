package by.ris.lab89.entity;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "clients", schema = "lab89")
@JacksonXmlRootElement(localName = "clients")
@JsonAutoDetect
public class ClientEntity {
    @JacksonXmlProperty
    private int id;
    @JacksonXmlProperty
   private String lastname;
    @JacksonXmlProperty
   private String firstname;
    @JacksonXmlProperty
   private String surname;
    @JacksonXmlProperty
   private Date birthday;
    @JacksonXmlProperty
   private Boolean hasork;
    @JacksonXmlProperty
   private String passportSeria;
    @JacksonXmlProperty
   private String address;
    @JacksonXmlProperty
   private String passportId;
    @JacksonXmlProperty
   private String phone;
    @JacksonXmlProperty
   private String citizenship;
    @JacksonXmlProperty
   private String email;

    @Id
    @GeneratedValue
    @Column(name = "id")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "lastname", nullable = false)
    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    @Basic
    @Column(name = "firstname", nullable = false)
    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    @Basic
    @Column(name = "surname")
    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    @Basic
    @Column(name = "birthday")
    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    @Basic
    @Column(name = "hasork")
    public Boolean getHasork() {
        return hasork;
    }

    public void setHasork(Boolean hasork) {
        this.hasork = hasork;
    }

    @Basic
    @Column(name = "passportSeria")
    public String getPassportSeria() {
        return passportSeria;
    }

    public void setPassportSeria(String passportSeria) {
        this.passportSeria = passportSeria;
    }

    @Basic
    @Column(name = "address")
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Basic
    @Column(name = "passportId")
    public String getPassportId() {
        return passportId;
    }

    public void setPassportId(String passportId) {
        this.passportId = passportId;
    }

    @Basic
    @Column(name = "phone")
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }


    @Basic
    @Column(name = "citizenship")
    public String getCitizenship() {
        return citizenship;
    }

    public void setCitizenship(String citizenship) {
        this.citizenship = citizenship;
    }

    @Basic
    @Column(name = "email")
    public String getEmail() { return email; }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ClientEntity that = (ClientEntity) o;

        if (id != that.id) return false;
        if (lastname != null ? !lastname.equals(that.lastname) : that.lastname != null) return false;
        if (firstname != null ? !firstname.equals(that.firstname) : that.firstname != null) return false;
        if (surname != null ? !surname.equals(that.surname) : that.surname != null) return false;
        if (birthday != null ? !birthday.equals(that.birthday) : that.birthday != null) return false;
        if (hasork != null ? !hasork.equals(that.hasork) : that.hasork != null) return false;
        if (passportSeria != null ? !passportSeria.equals(that.passportSeria) : that.passportSeria != null) return false;
        if (address != null ? !address.equals(that.address) : that.address != null) return false;
        if (passportId != null ? !passportId.equals(that.passportId) : that.passportId != null) return false;
        if (phone != null ? !phone.equals(that.phone) : that.phone != null) return false;
        if (citizenship != null ? !citizenship.equals(that.citizenship) : that.citizenship != null) return false;
        if (email != null ? !email.equals(that.email) : that.email != null) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (lastname != null ? lastname.hashCode() : 0);
        result = 31 * result + (firstname != null ? firstname.hashCode() : 0);
        result = 31 * result + (surname != null ? surname.hashCode() : 0);
        result = 31 * result + (birthday != null ? birthday.hashCode() : 0);
        result = 31 * result + (hasork != null ? hasork.hashCode() : 0);
        result = 31 * result + (passportSeria != null ? passportSeria.hashCode() : 0);
        result = 31 * result + (address != null ? address.hashCode() : 0);
        result = 31 * result + (passportId != null ? passportId.hashCode() : 0);
        result = 31 * result + (phone != null ? phone.hashCode() : 0);
        result = 31 * result + (citizenship != null ? citizenship.hashCode() : 0);
        result = 31 * result + (email != null ? email.hashCode() : 0);
        return result;
    }
}
