package com.laba6.lab6;

import javax.jws.WebService;
import java.io.File;
import java.io.FileNotFoundException;
import java.rmi.RemoteException;
import java.util.Scanner;

@WebService(endpointInterface = "com.laba6.lab6.LabIF")
public class LabImpl implements LabIF {

    @Override
    public String searchCar(String searchParameter, String value) throws RemoteException {
        File file = new File("cars.txt");
        StringBuilder result = new StringBuilder();
        try {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String data = scanner.nextLine();
                String[] arr = data.split(" ");
                if (searchParameter.equalsIgnoreCase("repairType")) {
                    if (arr[1].equalsIgnoreCase(value)) {
                        result.append(data).append('\n');
                    }
                } else if (searchParameter.equalsIgnoreCase("breakage")) {
                    if (arr[2].equalsIgnoreCase(value)) {
                        result.append(data).append('\n');
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return result.toString();
    }

}
