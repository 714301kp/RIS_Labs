package com.laba6.lab6;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.Scanner;

public class LabClient {

    public static void main(String[] args) {
        try {
            URL url = new URL("http://localhost:8080/ws/hello?wsdl");
            QName qname = new QName("http://lab6.laba6.com/", "LabImplService");
            Service service = Service.create(url, qname);
            LabIF hello = service.getPort(LabIF.class);

            int choice;
            String login;
            String password;
            Scanner scanner = new Scanner(System.in);
            System.out.println("Please log in");
            System.out.println("enter your login");
            login = scanner.next();
            System.out.println("enter your password");
            password = scanner.next();
            File file = new File("authorization.txt");
            Scanner scanner1 = new Scanner(file);
            while (scanner1.hasNextLine()) {
                String data = scanner1.nextLine();
                String[] arr = data.split(" ");
                System.out.println(login);
                System.out.println(password);
                System.out.println(arr[0]);
                System.out.println(arr[1]);
                if (login.equals(arr[0]) && password.equals(arr[1])) {
                    System.out.println("Ur welcome");
                    while (true) {
                        Scanner scanner2 = new Scanner(System.in);
                        System.out.println("1 - search by breakage");
                        System.out.println("2 - search by repairType");
                        System.out.println("0 - exit");
                        choice = scanner2.nextInt();

                        if (choice == 0) {
                            return;
                        }

                        String searchParameter = "";
                        String searchValue = "";


                        if (choice > 2 || choice < 1) {
                            continue;
                        }

                        if (choice == 1) {
                            searchParameter = "breakage";
                        } else {
                            searchParameter = "repairType";
                        }

                        System.out.println("Enter the " + searchParameter + ": ");
                        scanner.nextLine();
                        searchValue = scanner.nextLine();

                        System.out.println(hello.searchCar(searchParameter, searchValue));
                    }
                }
            }
        } catch (MalformedURLException | RemoteException | FileNotFoundException e) {
            e.printStackTrace();
        }
    }

}
