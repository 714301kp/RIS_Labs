package lab6;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

@WebService
@SOAPBinding(style = Style.RPC)
public interface Product {
    @WebMethod String findProductByName(String name);
    @WebMethod String findProductByPrice(Integer price);
    @WebMethod String showAllProducts();
    @WebMethod Integer calculatePrice();
}