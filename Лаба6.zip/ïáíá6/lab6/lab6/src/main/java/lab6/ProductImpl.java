package lab6;

import javax.jws.WebService;

@WebService(endpointInterface = "lab6.Product")
public class ProductImpl implements Product {
    private final ProductEntity[] products = {
            new ProductEntity("Bread", 5),
            new ProductEntity("Egg", 2),
            new ProductEntity("Bean",  4)
    };


    @Override
    public String findProductByName(String name) {
        for (ProductEntity product: products) {
            if (product.getName().equals(name)) {
                return product.toString();
            }
        }
        return "No such product";
    }

    @Override
    public String findProductByPrice(Integer price) {
        for (ProductEntity product: products) {
            if (product.getPrice().equals(price)) {
                return product.toString();
            }
        }
        return "No such product";
    }

    @Override
    public String showAllProducts() {
        String productsString = "";
        for (ProductEntity product: products) {
            productsString += product.toString() + "\n";
        }
        return productsString;
    }

    @Override
    public Integer calculatePrice() {
        int cost = 0;
        for (ProductEntity product: products) {
            cost += product.getPrice();
        }
        return cost;
    }
}
