package lab6;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class Client {
    public static void main(String[] args) throws Exception {
        URL url = new URL("http://localhost:7789/lab6?wsdl");
        QName qname = new QName("http://lab6/", "ProductImplService");
        Service service = Service.create(url, qname);
        Product product = service.getPort(Product.class);

        BufferedReader reader =
                new BufferedReader(new InputStreamReader(System.in));

        while (true){
            System.out.println("Select action: \n1 - Search by product name\n2 - Search by price" +
                    "\n3 - Show all products\n4 - Calculate all products price\nAny other key - Exit");

            int searchType = Integer.parseInt(reader.readLine());
            if (searchType == 1) {
                System.out.print("Input product name: ");
                String name = reader.readLine();
                System.out.println("Product: " + product.findProductByName(name));
            } else if (searchType == 2){
                System.out.print("Input price: ");
                Integer price = Integer.valueOf(reader.readLine());
                System.out.println("Product: " + product.findProductByPrice(price));
            } else if (searchType == 3) {
                System.out.println(product.showAllProducts());
            }  else if (searchType == 4) {
                System.out.println("Price sum: " + product.calculatePrice());
            } else {
                break;
            }
        }
    }
}